import boto3
import os
import json
from moviepy.editor import VideoFileClip

s3 = boto3.client('s3')
lambda_client = boto3.client('lambda')

def lambda_handler(event, context):
    bucket_name = os.environ['VIDEO_BUCKET_NAME']
    output_bucket = os.environ['IMAGES_BUCKET_NAME']
    file_name = event['file_name']
    video_url = event['video_url']
    user_id = event['user_id']

    video_path = f"/tmp/{file_name}"
    image_path = f"/tmp/{file_name.split('.')[0]}_middle_frame.jpg"

    try:
        # Download video from S3
        s3.download_file(bucket_name, file_name, video_path)
        print(f"Video downloaded to: {video_path}")

        # Extract the middle frame using MoviePy
        clip = VideoFileClip(video_path)
        middle_time = clip.duration / 2
        clip.save_frame(image_path, t=middle_time)
        clip.close()
        print(f"Middle frame saved to: {image_path}")

        # Upload middle frame to S3
        image_s3_key = f"frames/{file_name.split('.')[0]}_middle_frame.jpg"
        s3.upload_file(image_path, output_bucket, image_s3_key)
        image_url = f"https://{output_bucket}.s3.amazonaws.com/{image_s3_key}"
        print(f"Middle frame uploaded to: {image_url}")

        # Trigger the next Lambda function for subtitle extraction (if applicable)
        # lambda_client.invoke(
        #     FunctionName='ExtractSubtitlesFunction',
        #     InvocationType='Event',
        #     Payload=json.dumps({
        #         'user_id': user_id,
        #         'file_name': file_name,
        #         'video_url': video_url,
        #         'image_url': image_url
        #     })
        # )

        return {
            'statusCode': 200,
            'body': json.dumps({'image_url': image_url})
        }

    except Exception as e:
        print(f"Error: {e}")
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}
