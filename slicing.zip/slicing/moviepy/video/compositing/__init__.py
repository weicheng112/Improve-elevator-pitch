"""All for compositing video clips."""
